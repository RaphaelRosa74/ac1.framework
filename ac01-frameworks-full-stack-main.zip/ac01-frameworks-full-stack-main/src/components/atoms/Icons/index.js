import { GoogleIcon } from "./GoogleIcon";
import { ThunderIcon } from "./ThunderIcon";

export { GoogleIcon, ThunderIcon };
